/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemas.de.reserva.hotel.clave.pkg1;

/**
 *
 * @author Pavilion X360
 */
public class SistemasDeReservaHotelCLAVE1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        GestionClientes ventana = new GestionClientes();
ventana.setVisible(true);
        // 
    System.out.println("===============================");
    System.out.println(" SISTEMA DE RESERVA DE HOTEL");
    System.out.println("================================");
    System.out.println("Bienvenido al sistema.");
    System.out.println("Grupo 1 - Clave 1");
 
    java.util.Scanner entrada = new java.util.Scanner(System.in);
    
    int opcion = 0; 
    
    java.util.ArrayList<Habitacion> habitaciones =
        new java.util.ArrayList<>();

    int siguienteHabitacion = 1;

    java.util.ArrayList<Huesped> huespedes =
        new java.util.ArrayList<>();

    int siguienteHuesped = 1;
    
    java.util.ArrayList<Reserva> reservas =
        new java.util.ArrayList<>();

    int siguienteReserva = 1;
    
    do {
        System.out.println("\n==== MENU PRINCIPAL ====");
        System.out.println("1. Registrar habitación");
        System.out.println("2. Registrar huesped"); 
        System.out.println("3. Consultar habitaciones");
        System.out.println("4. Consultar huespedes");
        System.out.println("5. Realizar reserva");
        System.out.println("6. Consultar reservas");
        System.out.println("7. Cancelar reserva");
        System.out.println("8. Calcular costo de hospedaje");
        System.out.println("9. Modificar precio de habitacion");
        System.out.println("10. Consultar habitaciones disponibles");
        System.out.println("11. Modificar datos de huesped");
        System.out.println("0. Salir");
        
        System.out.println("Seleccione una opcion:"); 
        if (entrada.hasNextInt()) {
    opcion = entrada.nextInt();
} else {
    System.out.println("Error: debe ingresar un numero.");
    entrada.nextLine();
    opcion = -1;
} 
      if (opcion == 1) {

    entrada.nextLine();

    System.out.println("\n=== REGISTRAR HABITACION ===");

    System.out.print("¿La habitacion esta disponible? (Si/No): ");
    String disponible = entrada.nextLine();

    if (disponible.equalsIgnoreCase("Si")) {

        System.out.print("Ingrese el tipo de habitacion: ");
        String tipo = entrada.nextLine();

        double precio = 0;
boolean precioValido = false;

while (!precioValido) {

    System.out.print("Ingrese el precio por noche: ");

    if (entrada.hasNextDouble()) {

        precio = entrada.nextDouble();

        if (precio > 0) {
            precioValido = true;
        } else {
            System.out.println("El precio debe ser mayor que cero.");
        }

    } else {

        System.out.println("Error: ingrese un precio numerico.");
        entrada.nextLine();

    }
}
       entrada.nextLine();
       
        if (tipo.isBlank() || precio <= 0) {
            System.out.println("Datos no validos.");
        } else {
            
            entrada.nextLine();
            System.out.print("Ingrese el codigo de la habitacion: ");
String codigo = entrada.nextLine().trim();

while (codigo.isEmpty()) {
    System.out.println("El codigo no puede estar vacio.");
    System.out.print("Ingrese el codigo: ");
    codigo = entrada.nextLine().trim();
}

System.out.print("Ingrese la capacidad de personas: ");
int capacidad = Integer.parseInt(entrada.nextLine().trim());

while (capacidad <= 0) {
    System.out.println("La capacidad debe ser mayor que cero.");
    System.out.print("Ingrese la capacidad: ");
    capacidad = Integer.parseInt(entrada.nextLine().trim());
}

Habitacion nueva = new Habitacion(
    codigo, siguienteHabitacion, tipo, capacidad, precio);


            habitaciones.add(nueva);

            System.out.println("Habitacion registrada correctamente.");
            System.out.println("Estado: Disponible");
            System.out.println("Numero asignado: " + siguienteHabitacion);

            siguienteHabitacion++;
        }

    } else if (disponible.equalsIgnoreCase("No")) {

        System.out.println("La habitacion no esta disponible.");
        System.out.println("Regresando al menu principal...");

    } else {

        System.out.println("Respuesta no valida. Regresando al menu.");

    }
}

// OPCION 3: CONSULTAR HABITACIONES

if (opcion == 2) {

    entrada.nextLine();

    System.out.println("\n=== REGISTRAR HUESPED ===");

    String nombre = "";

while (nombre.isBlank()) {

    System.out.print("Ingrese el nombre del huesped: ");
    nombre = entrada.nextLine();

    if (nombre.isBlank()) {
        System.out.println("Error: el nombre no puede estar vacio.");
    }
}

    String telefono = "";

while (telefono.isBlank()) {

    System.out.print("Ingrese el telefono: ");
    telefono = entrada.nextLine();

    if (telefono.isBlank()) {
        System.out.println("Error: el telefono no puede estar vacio.");
    }
}

    if (nombre.isBlank() || telefono.isBlank()) {

        System.out.println("Datos no validos.");

    } else {

        System.out.print("Ingrese el documento de identidad: ");
String documento = entrada.nextLine();

while (documento.isBlank()) {
    System.out.println("El documento no puede estar vacio.");
    System.out.print("Ingrese el documento: ");
    documento = entrada.nextLine();
}

System.out.print("Ingrese el correo electronico (opcional): ");
String correo = entrada.nextLine();

while (!correo.isBlank() &&
       !correo.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) {

    System.out.println("El correo no es valido.");
    System.out.print("Ingrese nuevamente el correo: ");
    correo = entrada.nextLine();
}

        Huesped nuevo = new Huesped(
                  siguienteHuesped, nombre, telefono, documento, correo);

        huespedes.add(nuevo);

        System.out.println("Huesped registrado correctamente.");
        System.out.println("ID asignado: " + siguienteHuesped);

        siguienteHuesped++;
    }
}

if (opcion == 3) {

    System.out.println("\n=== CONSULTAR HABITACIONES ===");

    if (habitaciones.isEmpty()) {

        System.out.println("No hay habitaciones registradas.");

    } else {

        for (Habitacion habitacion : habitaciones) {

            habitacion.mostrarInformacion();

        }
    }
}
if (opcion == 4) {

    System.out.println("\n=== CONSULTAR HUESPEDES ===");

    if (huespedes.isEmpty()) {

        System.out.println("No hay huespedes registrados.");

    } else {

        for (Huesped huesped : huespedes) {
            huesped.mostrarInformacion();
        }

    }
}
if (opcion == 5) {

    System.out.println("\n=== REALIZAR RESERVA ===");

    if (huespedes.isEmpty() || habitaciones.isEmpty()) {

        System.out.println("Primero debe registrar huespedes y habitaciones.");

    } else {

       int idHuesped = 0;
boolean idValido = false;

while (!idValido) {

    System.out.print("Ingrese el ID del huesped: ");

    if (entrada.hasNextInt()) {

        idHuesped = entrada.nextInt();

        if (idHuesped > 0) {
            idValido = true;
        } else {
            System.out.println("El ID debe ser mayor que cero.");
        }

    } else {

        System.out.println("Error: debe ingresar un numero.");
        entrada.nextLine();

    }
}
        Huesped huespedSeleccionado = null;

        for (Huesped h : huespedes) {
            if (h.getId() == idHuesped) {
                huespedSeleccionado = h;
                break;
            }
        }

       int numeroHabitacion = 0;
boolean habitacionValida = false;

while (!habitacionValida) {

    System.out.print("Ingrese el numero de habitacion: ");

    if (entrada.hasNextInt()) {

        numeroHabitacion = entrada.nextInt();

        if (numeroHabitacion > 0) {
            habitacionValida = true;
        } else {
            System.out.println("El numero debe ser mayor que cero.");
        }

    } else {

        System.out.println("Error: debe ingresar un numero.");
        entrada.nextLine();

    }
}

        Habitacion habitacionSeleccionada = null;

        for (Habitacion h : habitaciones) {
            if (h.getNumero() == numeroHabitacion) {
                habitacionSeleccionada = h;
                break;
            }
        }

        if (huespedSeleccionado == null ||
            habitacionSeleccionada == null) {

            System.out.println("Huesped o habitacion no encontrado.");

        } else if (!habitacionSeleccionada.getEstado()
                .equalsIgnoreCase("Disponible")) {

            System.out.println("La habitacion no esta disponible.");

        } else {

           int dias = 0;
boolean diasValidos = false;

while (!diasValidos) {

    System.out.print("Ingrese los dias de hospedaje: ");

    if (entrada.hasNextInt()) {

        dias = entrada.nextInt();

        if (dias > 0) {
            diasValidos = true;
        } else {
            System.out.println("Los dias deben ser mayores que cero.");
        }

    } else {

        System.out.println("Error: debe ingresar un numero entero.");
        entrada.nextLine();

    }
}

            if (dias <= 0) {

                System.out.println("Los dias deben ser mayores que cero.");

            } else {

                Reserva nuevaReserva = new Reserva(
                        siguienteReserva,
                        huespedSeleccionado,
                        habitacionSeleccionada,
                        dias);

                reservas.add(nuevaReserva);

                habitacionSeleccionada.setEstado("Reservada");

                System.out.println("Reserva realizada correctamente.");
                System.out.println("Numero de reserva: " + siguienteReserva);
                System.out.println("Costo total: $" +
                        nuevaReserva.calcularCosto());

                siguienteReserva++;
            }
        }
    }
}
if (opcion == 6) {

    System.out.println("\n=== CONSULTAR RESERVAS ===");

    if (reservas.isEmpty()) {

        System.out.println("No hay reservas registradas.");

    } else {

        for (Reserva reserva : reservas) {
            reserva.mostrarInformacion();
        }

    }
}

if (opcion == 7) {

    System.out.println("\n=== CANCELAR RESERVA ===");

    if (reservas.isEmpty()) {

        System.out.println("No hay reservas registradas.");

    } else {

       int numeroReserva = 0;
boolean numeroValido = false;

while (!numeroValido) {

    System.out.print("Ingrese el numero de reserva: ");

    if (entrada.hasNextInt()) {

        numeroReserva = entrada.nextInt();

        if (numeroReserva > 0) {
            numeroValido = true;
        } else {
            System.out.println("El numero debe ser mayor que cero.");
        }

    } else {

        System.out.println("Error: debe ingresar un numero entero.");
        entrada.nextLine();

    }
}

        Reserva reservaSeleccionada = null;

        for (Reserva r : reservas) {

            if (r.getId() == numeroReserva) {
                reservaSeleccionada = r;
                break;
            }
        }

        if (reservaSeleccionada == null) {

            System.out.println("Reserva no encontrada.");

        } else if (reservaSeleccionada.getEstado()
                .equalsIgnoreCase("Cancelada")) {

            System.out.println("Esta reserva ya fue cancelada.");

        } else {

            System.out.print("¿Desea cancelar esta reserva? (Si/No): ");
            String confirmar = entrada.next();

            if (confirmar.equalsIgnoreCase("Si")) {

                reservaSeleccionada.cancelarReserva();

                System.out.println("Reserva cancelada correctamente.");
                System.out.println("La habitacion vuelve a estar disponible.");

            } else {

                System.out.println("Cancelacion no realizada.");
                System.out.println("Regresando al menu principal.");

            }
        }
    }
}

if (opcion == 8) {

    System.out.println("\n=== CALCULAR COSTO DE HOSPEDAJE ===");

    if (reservas.isEmpty()) {

        System.out.println("No hay reservas registradas.");

    } else {

        int numeroReserva = 0;
boolean numeroReservaValido = false;

while (!numeroReservaValido) {

    System.out.print("Ingrese el numero de reserva: ");

    if (entrada.hasNextInt()) {

        numeroReserva = entrada.nextInt();

        if (numeroReserva > 0) {
            numeroReservaValido = true;
        } else {
            System.out.println("El numero debe ser mayor que cero.");
        }

    } else {

        System.out.println("Error: debe ingresar un numero entero.");
        entrada.nextLine();

    }
}

        Reserva reservaSeleccionada = null;

        for (Reserva r : reservas) {

            if (r.getId() == numeroReserva) {
                reservaSeleccionada = r;
                break;
            }
        }

        if (reservaSeleccionada == null) {

            System.out.println("Reserva no encontrada.");

        } else if (reservaSeleccionada.getEstado()
                .equalsIgnoreCase("Cancelada")) {

            System.out.println("No se calcula el costo de una reserva cancelada.");

        } else {

            System.out.println("Huesped: "
                    + reservaSeleccionada.getHuesped().getNombre());

            System.out.println("Habitacion: "
                    + reservaSeleccionada.getHabitacion().getNumero());

            System.out.println("Costo total: $"
                    + reservaSeleccionada.calcularCosto());
        }
    }
}

if (opcion == 9) {

    System.out.println("\n=== MODIFICAR PRECIO DE HABITACION ===");

    if (habitaciones.isEmpty()) {

        System.out.println("No hay habitaciones registradas.");

    } else {

        int numeroHabitacion = 0;
boolean numeroValido = false;

while (!numeroValido) {

    System.out.print("Ingrese el numero de habitacion: ");

    if (entrada.hasNextInt()) {

        numeroHabitacion = entrada.nextInt();

        if (numeroHabitacion > 0) {
            numeroValido = true;
        } else {
            System.out.println("El numero debe ser mayor que cero.");
        }

    } else {

        System.out.println("Error: debe ingresar un numero.");
        entrada.nextLine();

    }
}

        Habitacion habitacionSeleccionada = null;

        for (Habitacion h : habitaciones) {

            if (h.getNumero() == numeroHabitacion) {
                habitacionSeleccionada = h;
                break;
            }
        }

        if (habitacionSeleccionada == null) {

            System.out.println("Habitacion no encontrada.");

        } else {

            System.out.println("Precio actual: $"
                    + habitacionSeleccionada.getPrecio());

            double nuevoPrecio = 0;
boolean nuevoPrecioValido = false;

while (!nuevoPrecioValido) {

    System.out.print("Ingrese el nuevo precio: ");

    if (entrada.hasNextDouble()) {

        nuevoPrecio = entrada.nextDouble();

        if (nuevoPrecio > 0) {
            nuevoPrecioValido = true;
        } else {
            System.out.println("El precio debe ser mayor que cero.");
        }

    } else {

        System.out.println("Error: ingrese un precio numerico.");
        entrada.nextLine();

    }
}

            if (nuevoPrecio <= 0) {

                System.out.println("El precio debe ser mayor que cero.");

            } else {

                habitacionSeleccionada.setPrecio(nuevoPrecio);

                System.out.println("Precio actualizado correctamente.");
                System.out.println("Nuevo precio: $"
                        + habitacionSeleccionada.getPrecio());
            }
        }
    }
}

if (opcion == 10) {

    System.out.println("\n=== HABITACIONES DISPONIBLES ===");

    if (habitaciones.isEmpty()) {

        System.out.println("No hay habitaciones registradas.");

    } else {

        boolean hayDisponibles = false;

        for (Habitacion h : habitaciones) {

            if (h.getEstado().equalsIgnoreCase("Disponible")) {

                h.mostrarInformacion();
                hayDisponibles = true;

            }
        }

        if (!hayDisponibles) {

            System.out.println("No hay habitaciones disponibles.");

        }
    }
}

if (opcion == 11) {

    System.out.println("\n=== MODIFICAR DATOS DE HUESPED ===");

    if (huespedes.isEmpty()) {

        System.out.println("No hay huespedes registrados.");

    } else {

       int idHuesped = 0;
boolean idValido = false;

while (!idValido) {

    System.out.print("Ingrese el ID del huesped: ");

    if (entrada.hasNextInt()) {

        idHuesped = entrada.nextInt();

        if (idHuesped > 0) {
            idValido = true;
        } else {
            System.out.println("El ID debe ser mayor que cero.");
        }

    } else {

        System.out.println("Error: debe ingresar un numero entero.");
        entrada.nextLine();

    }
}

entrada.nextLine();

        Huesped huespedSeleccionado = null;

        for (Huesped h : huespedes) {

            if (h.getId() == idHuesped) {
                huespedSeleccionado = h;
                break;
            }
        }

        if (huespedSeleccionado == null) {

            System.out.println("Huesped no encontrado.");

        } else {

            System.out.println("Nombre actual: "
                    + huespedSeleccionado.getNombre());

            System.out.println("Telefono actual: "
                    + huespedSeleccionado.getTelefono());

            System.out.print("Ingrese el nuevo nombre: ");
            String nuevoNombre = entrada.nextLine();

            System.out.print("Ingrese el nuevo telefono: ");
            String nuevoTelefono = entrada.nextLine();

            if (nuevoNombre.isBlank() || nuevoTelefono.isBlank()) {

                System.out.println("Los datos no pueden estar vacios.");

            } else {

                huespedSeleccionado.setNombre(nuevoNombre);
                huespedSeleccionado.setTelefono(nuevoTelefono);

                System.out.println("Datos actualizados correctamente.");
            }
        }
    }
}

} while (opcion != 0);

}
}