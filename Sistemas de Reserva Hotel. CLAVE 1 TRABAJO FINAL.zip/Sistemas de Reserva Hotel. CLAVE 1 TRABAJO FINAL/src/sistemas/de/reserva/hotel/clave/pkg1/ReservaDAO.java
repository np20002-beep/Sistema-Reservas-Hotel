
package sistemas.de.reserva.hotel.clave.pkg1;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class ReservaDAO {

    private final MongoCollection<Document> reservas;
    private final MongoCollection<Document> clientes;
    private final MongoCollection<Document> habitaciones;

    public ReservaDAO() {
        var base = ConexionMongoDB.conectar();

        reservas = base.getCollection("reservas");
        clientes = base.getCollection("clientes");
        habitaciones = base.getCollection("habitaciones");
    }

    public double calcularTotal(
            String codigoHabitacion,
            String entrada,
            String salida) {

        LocalDate fechaEntrada = LocalDate.parse(entrada);
        LocalDate fechaSalida = LocalDate.parse(salida);

if (fechaEntrada.isBefore(LocalDate.now())) {
    throw new IllegalArgumentException(
            "No se pueden realizar reservas con fechas pasadas.");
}

        long noches = ChronoUnit.DAYS.between(
                fechaEntrada, fechaSalida);

        if (noches <= 0) {
            throw new IllegalArgumentException(
                    "La fecha de salida debe ser posterior a la entrada.");
        }

        Document habitacion = habitaciones.find(
                Filters.eq("codigo", codigoHabitacion)).first();

        if (habitacion == null) {
            throw new IllegalArgumentException(
                    "La habitación no existe.");
        }

        double precio = habitacion.getDouble("precio");

        return noches * precio;
    }

    public boolean estaDisponible(
            String codigoHabitacion,
            String entrada,
            String salida) {

        Document habitacion = habitaciones.find(
                Filters.eq("codigo", codigoHabitacion)).first();

        if (habitacion == null ||
                !"Disponible".equals(
                        habitacion.getString("estado"))) {
            return false;
        }

        Document conflicto = reservas.find(
                Filters.and(
                        Filters.eq("habitacion", codigoHabitacion),
                        Filters.eq("estado", "Activa"),
                        Filters.lt("entrada", salida),
                        Filters.gt("salida", entrada)
                )
        ).first();

        return conflicto == null;
    }

    public void registrarReserva(
            String codigo,
            int codigoCliente,
            String codigoHabitacion,
            String entrada,
            String salida) {

        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "El código de reserva es obligatorio.");
        }

        if (reservas.find(
                Filters.eq("codigo", codigo.trim())).first() != null) {
            throw new IllegalArgumentException(
                    "Ya existe una reserva con ese código.");
        }

        Document cliente = clientes.find(
                Filters.eq("codigo", codigoCliente)).first();

        if (cliente == null ||
                "Inactivo".equals(cliente.getString("estado"))) {
            throw new IllegalArgumentException(
                    "El cliente no existe o está inactivo.");
        }

        double total = calcularTotal(
                codigoHabitacion, entrada, salida);

        if (!estaDisponible(
                codigoHabitacion, entrada, salida)) {
            throw new IllegalArgumentException(
                    "La habitación no está disponible en esas fechas.");
        }

        Document reserva = new Document()
                .append("codigo", codigo.trim())
                .append("cliente", codigoCliente)
                .append("habitacion", codigoHabitacion)
                .append("entrada", entrada)
                .append("salida", salida)
                .append("total", total)
                .append("estado", "Activa");

        reservas.insertOne(reserva);
    }
    
public boolean modificarReserva(
        String codigo,
        int codigoCliente,
        String codigoHabitacion,
        String entrada,
        String salida) {

    codigo = codigo.trim();
    codigoHabitacion = codigoHabitacion.trim();

    Document reservaActual = reservas.find(
            Filters.eq("codigo", codigo)).first();

    if (reservaActual == null) {
        throw new IllegalArgumentException(
                "No existe una reserva con ese código.");
    }

    if (!"Activa".equals(reservaActual.getString("estado"))) {
        throw new IllegalArgumentException(
                "Solamente se pueden modificar reservas activas.");
    }

    Document cliente = clientes.find(
            Filters.eq("codigo", codigoCliente)).first();

    if (cliente == null ||
            "Inactivo".equals(cliente.getString("estado"))) {
        throw new IllegalArgumentException(
                "El cliente no existe o está inactivo.");
    }

    double total = calcularTotal(
            codigoHabitacion, entrada, salida);

    Document habitacion = habitaciones.find(
            Filters.eq("codigo", codigoHabitacion)).first();

    if (!"Disponible".equals(habitacion.getString("estado"))) {
        throw new IllegalArgumentException(
                "La habitación no está disponible.");
    }

    Document conflicto = reservas.find(
            Filters.and(
                    Filters.ne("codigo", codigo),
                    Filters.eq("habitacion", codigoHabitacion),
                    Filters.eq("estado", "Activa"),
                    Filters.lt("entrada", salida),
                    Filters.gt("salida", entrada)
            )
    ).first();

    if (conflicto != null) {
        throw new IllegalArgumentException(
                "La habitación ya tiene otra reserva en esas fechas.");
    }

    Document cambios = new Document()
            .append("cliente", codigoCliente)
            .append("habitacion", codigoHabitacion)
            .append("entrada", entrada)
            .append("salida", salida)
            .append("total", total);

    return reservas.updateOne(
            Filters.and(
                    Filters.eq("codigo", codigo),
                    Filters.eq("estado", "Activa")
            ),
            new Document("$set", cambios)
    ).getMatchedCount() > 0;
}

public boolean cancelarReserva(String codigo) {

    if (codigo == null || codigo.trim().isEmpty()) {
        throw new IllegalArgumentException(
                "Ingresa el código de la reserva.");
    }

    Document reserva = reservas.find(
            Filters.eq("codigo", codigo.trim())).first();

    if (reserva == null) {
        throw new IllegalArgumentException(
                "No existe una reserva con ese código.");
    }

    if (!"Activa".equals(reserva.getString("estado"))) {
        throw new IllegalArgumentException(
                "Esta reserva ya está cancelada.");
    }

    return reservas.updateOne(
            Filters.and(
                    Filters.eq("codigo", codigo.trim()),
                    Filters.eq("estado", "Activa")
            ),
            new Document("$set",
                    new Document("estado", "Cancelada"))
    ).getModifiedCount() > 0;
}

}
