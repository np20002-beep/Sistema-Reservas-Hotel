
package sistemas.de.reserva.hotel.clave.pkg1;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import org.bson.Document;

public class ClienteDAO {

    private final MongoCollection<Document> coleccion;

    public ClienteDAO() {
        MongoDatabase base = ConexionMongoDB.conectar();
        coleccion = base.getCollection("clientes");
    }

    public void guardarCliente(Huesped huesped) {

        if (huesped == null) {
            throw new IllegalArgumentException(
                "El cliente no puede ser nulo");
        }

        // Verificar que el codigo no este repetido
        Document existente = coleccion.find(
            Filters.eq("codigo", huesped.getId())
        ).first();

        if (existente != null) {
            throw new IllegalArgumentException(
                "Ya existe un cliente con ese codigo");
        }

        // Verificar que el documento no este repetido
        Document documentoExistente = coleccion.find(
            Filters.eq("documento", huesped.getDocumento())
        ).first();

        if (documentoExistente != null) {
            throw new IllegalArgumentException(
                "Ya existe un cliente con ese documento");
        }

        Document datos = new Document()
            .append("codigo", huesped.getId())
            .append("nombre", huesped.getNombre())
            .append("documento", huesped.getDocumento())
            .append("telefono", huesped.getTelefono())
            .append("correo", huesped.getCorreo());

        coleccion.insertOne(datos);
        System.out.println("CLIENTE GUARDADO EN MONGODB");
    }
    public Document buscarCliente(int codigo) {

    return coleccion.find(
        Filters.eq("codigo", codigo)
    ).first();

}
    
public boolean modificarCliente(int codigo, String nombre,
        String documento, String telefono, String correo) {

    if (nombre == null || nombre.isBlank()
            || documento == null || documento.isBlank()) {
        throw new IllegalArgumentException(
            "El nombre y documento son obligatorios.");
    }

    if (!correo.isBlank() &&
            !correo.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) {
        throw new IllegalArgumentException(
            "El correo electronico no es valido.");
    }

    Document otro = coleccion.find(
        Filters.and(
            Filters.eq("documento", documento),
            Filters.ne("codigo", codigo)
        )
    ).first();

    if (otro != null) {
        throw new IllegalArgumentException(
            "El documento pertenece a otro cliente.");
    }

    Document cambios = new Document()
        .append("nombre", nombre)
        .append("documento", documento)
        .append("telefono", telefono)
        .append("correo", correo);

    return coleccion.updateOne(
        Filters.eq("codigo", codigo),
        new Document("$set", cambios)
    ).getMatchedCount() > 0;
}
public boolean inactivarCliente(int codigo) {

    Document cliente = coleccion.find(
        Filters.eq("codigo", codigo)
    ).first();

    if (cliente == null) {
        return false;
    }

    if ("Inactivo".equals(cliente.getString("estado"))) {
        throw new IllegalArgumentException(
            "Este cliente ya se encuentra inactivo.");
    }

    return coleccion.updateOne(
        Filters.eq("codigo", codigo),
        new Document("$set",
            new Document("estado", "Inactivo"))
    ).getModifiedCount() > 0;
}
}
