/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Pavilion X360
 */
package sistemas.de.reserva.hotel.clave.pkg1;

public class Huesped {

    private int id;
    private String nombre;
    private String telefono;
    private String documento;
    private String correo;

    public Huesped(int id, String nombre, String telefono,
               String documento, String correo) {

    if (id <= 0) {
        throw new IllegalArgumentException(
            "El ID debe ser mayor que cero");
    }

    if (nombre == null || nombre.isBlank()) {
        throw new IllegalArgumentException(
            "El nombre no puede estar vacio");
    }

    if (documento == null || documento.isBlank()) {
        throw new IllegalArgumentException(
            "El documento no puede estar vacio");
    }

    this.id = id;
    this.nombre = nombre;
    this.telefono = telefono;
    this.documento = documento;
    this.correo = correo;
}

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }
    
    public void setNombre(String nombre) {
    if (nombre != null && !nombre.isBlank()) {
        this.nombre = nombre;
    }
}

public void setTelefono(String telefono) {
    if (telefono != null && !telefono.isBlank()) {
        this.telefono = telefono;
    }
}

public String getDocumento() {
    return documento;
}

public void setDocumento(String documento) {
    if (documento == null || documento.isBlank()) {
        throw new IllegalArgumentException(
            "El documento no puede estar vacio");
    }
    this.documento = documento;
}

public String getCorreo() {
    return correo;
}

public void setCorreo(String correo) {
    if (correo != null && !correo.isBlank()
            && !correo.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) {
        throw new IllegalArgumentException(
            "El correo electronico no es valido");
    }
    this.correo = correo;
}
    public void mostrarInformacion() {
        System.out.println("------------------------");
        System.out.println("ID: " + id);
        System.out.println("Nombre: " + nombre);
        System.out.println("Telefono: " + telefono);
    }
}