package sistemas.de.reserva.hotel.clave.pkg1;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import org.bson.Document;

public class HabitacionDAO {

    private final MongoCollection<Document> coleccion;

    public HabitacionDAO() {
        coleccion = ConexionMongoDB.conectar()
                .getCollection("habitaciones");
    }

    public void registrarHabitacion(
            String codigo,
            int numero,
            String tipo,
            int capacidad,
            double precio,
            String estado) {

        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "El código no puede estar vacío.");
        }

        if (numero <= 0 || capacidad <= 0 || precio <= 0) {
            throw new IllegalArgumentException(
                    "El número, la capacidad y el precio deben ser mayores que cero.");
        }

        if (coleccion.find(Filters.eq("codigo", codigo)).first() != null) {
            throw new IllegalArgumentException(
                    "Ya existe una habitación con ese código.");
        }

        if (coleccion.find(Filters.eq("numero", numero)).first() != null) {
            throw new IllegalArgumentException(
                    "Ya existe una habitación con ese número.");
        }

        Document habitacion = new Document()
                .append("codigo", codigo.trim())
                .append("numero", numero)
                .append("tipo", tipo)
                .append("capacidad", capacidad)
                .append("precio", precio)
                .append("estado", estado);

        coleccion.insertOne(habitacion);
    }

    public Document buscarHabitacion(String codigo) {
        return coleccion.find(Filters.eq("codigo", codigo.trim()))
                .first();
    }

    public boolean modificarHabitacion(
            String codigo,
            String tipo,
            int capacidad,
            double precio) {

        if (capacidad <= 0 || precio <= 0) {
            throw new IllegalArgumentException(
                    "La capacidad y el precio deben ser mayores que cero.");
        }

        Document cambios = new Document()
                .append("tipo", tipo)
                .append("capacidad", capacidad)
                .append("precio", precio);

        return coleccion.updateOne(
                Filters.eq("codigo", codigo.trim()),
                new Document("$set", cambios)
        ).getMatchedCount() > 0;
    }

    public boolean cambiarEstado(String codigo, String estado) {
        return coleccion.updateOne(
                Filters.eq("codigo", codigo.trim()),
                Updates.set("estado", estado)
        ).getMatchedCount() > 0;
    }
}