
package sistemas.de.reserva.hotel.clave.pkg1;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

public class ConexionMongoDB {

    private static MongoClient cliente;

    public static MongoDatabase conectar() {

        if (cliente == null) {
            cliente = MongoClients.create(
                "mongodb://localhost:27017"
            );
        }

        return cliente.getDatabase("hotel_reservas");
    }

    public static void cerrar() {
        if (cliente != null) {
            cliente.close();
            cliente = null;
        }
    }
}

