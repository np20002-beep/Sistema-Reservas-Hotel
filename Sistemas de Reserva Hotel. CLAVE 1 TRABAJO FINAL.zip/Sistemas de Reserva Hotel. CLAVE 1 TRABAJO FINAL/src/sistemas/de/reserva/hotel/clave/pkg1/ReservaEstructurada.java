/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Pavilion X360
 */
package sistemas.de.reserva.hotel.clave.pkg1;

public class ReservaEstructurada {

public static void main(String[] args) {

    java.util.Scanner entrada = new java.util.Scanner(System.in);

    int opcion;
   
int[] numerosHabitaciones = new int[50];
String[] tiposHabitaciones = new String[50];
double[] preciosHabitaciones = new double[50];
boolean[] habitacionesDisponibles = new boolean[50];

int cantidadHabitaciones = 0;

int[] idsClientes = new int[50];
String[] nombresClientes = new String[50];
String[] telefonosClientes = new String[50];
int cantidadClientes = 0;
int[] reservasClientes = new int[50];
int[] reservasHabitaciones = new int[50];
int[] reservasNoches = new int[50];
boolean[] reservasActivas = new boolean[50];
int cantidadReservas = 0;

    do {
        System.out.println("\n=== SISTEMA DE RESERVAS DE HOTEL ===");
        System.out.println("PROGRAMACION ESTRUCTURADA");
        System.out.println("1. Registrar habitacion");
        System.out.println("2. Registrar cliente");
        System.out.println("3. Consultar habitaciones disponibles");
        System.out.println("4. Realizar reserva");
        System.out.println("5. Cancelar reserva");
        System.out.println("6. Consultar reservas");
        System.out.println("7. Calcular costo de reserva");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opcion: ");

        if (entrada.hasNextInt()) {
            opcion = entrada.nextInt();
        } else {
            System.out.println("Error: ingrese un numero.");
            entrada.nextLine();
            opcion = -1;
        }

        if (opcion == 0) {
            System.out.println("Gracias por utilizar el sistema.");
        } else if (opcion < 0 || opcion > 7) {
            System.out.println("Opcion no valida.");
       } else if (opcion == 1) {

    cantidadHabitaciones = registrarHabitacion(
            entrada,
            numerosHabitaciones,
            tiposHabitaciones,
            preciosHabitaciones,
            habitacionesDisponibles,
            cantidadHabitaciones);

} else if (opcion == 2) {

    cantidadClientes = registrarCliente(
            entrada,
            idsClientes,
            nombresClientes,
            telefonosClientes,
            cantidadClientes);

} else if (opcion == 3) {

    consultarHabitacionesDisponibles(
            numerosHabitaciones,
            tiposHabitaciones,
            preciosHabitaciones,
            habitacionesDisponibles,
            cantidadHabitaciones);

} else if (opcion == 4) {

    cantidadReservas = realizarReserva(
            entrada,
            idsClientes,
            cantidadClientes,
            numerosHabitaciones,
            habitacionesDisponibles,
            cantidadHabitaciones,
            reservasClientes,
            reservasHabitaciones,
            reservasNoches,
            reservasActivas,
            cantidadReservas);

} else if (opcion == 5) {

    cancelarReserva(
            entrada,
            reservasHabitaciones,
            reservasActivas,
            cantidadReservas,
            numerosHabitaciones,
            habitacionesDisponibles,
            cantidadHabitaciones);

} else if (opcion == 6) {

    consultarReservas(
            reservasClientes,
            reservasHabitaciones,
            reservasNoches,
            reservasActivas,
            cantidadReservas);

} else if (opcion == 7) {

    calcularCostoReserva(
            entrada,
            reservasHabitaciones,
            reservasNoches,
            reservasActivas,
            cantidadReservas,
            numerosHabitaciones,
            preciosHabitaciones,
            cantidadHabitaciones);

} else {
    System.out.println("Esta opcion se programara a continuacion.");
}
        
           } while (opcion != 0);

}

public static int registrarHabitacion(
        java.util.Scanner entrada,
        int[] numeros,
        String[] tipos,
        double[] precios,
        boolean[] disponibles,
        int cantidad) {

    if (cantidad >= numeros.length) {
        System.out.println("No se pueden registrar mas habitaciones.");
        return cantidad;
    }

    entrada.nextLine();

    System.out.print("Ingrese el tipo de habitacion: ");
    String tipo = entrada.nextLine();

    if (tipo.isBlank()) {
        System.out.println("Error: el tipo no puede estar vacio.");
        return cantidad;
    }

    System.out.print("Ingrese el precio por noche: ");

    if (!entrada.hasNextDouble()) {
        System.out.println("Error: debe ingresar un precio numerico.");
        entrada.nextLine();
        return cantidad;
    }

    double precio = entrada.nextDouble();

    if (precio <= 0) {
        System.out.println("Error: el precio debe ser mayor que cero.");
        return cantidad;
    }

    numeros[cantidad] = cantidad + 1;
    tipos[cantidad] = tipo;
    precios[cantidad] = precio;
    disponibles[cantidad] = true;

    cantidad++;

    System.out.println("Habitacion registrada correctamente.");
    System.out.println("Numero asignado: " + cantidad);

    return cantidad;
}


public static int registrarCliente(
        java.util.Scanner entrada,
        int[] ids,
        String[] nombres,
        String[] telefonos,
        int cantidad) {

    if (cantidad >= ids.length) {
        System.out.println("No se pueden registrar mas clientes.");
        return cantidad;
    }

    entrada.nextLine();

    String nombre = "";

    while (nombre.isBlank()) {
        System.out.print("Ingrese el nombre del cliente: ");
        nombre = entrada.nextLine();

        if (nombre.isBlank()) {
            System.out.println("Error: el nombre no puede estar vacio.");
        }
    }

    String telefono = "";

    while (telefono.isBlank()) {
        System.out.print("Ingrese el telefono: ");
        telefono = entrada.nextLine();

        if (telefono.isBlank()) {
            System.out.println("Error: el telefono no puede estar vacio.");
        }
    }

    ids[cantidad] = cantidad + 1;
    nombres[cantidad] = nombre;
    telefonos[cantidad] = telefono;

    cantidad++;

    System.out.println("Cliente registrado correctamente.");
    System.out.println("ID asignado: " + cantidad);

    return cantidad;
}

public static void consultarHabitacionesDisponibles(
        int[] numeros,
        String[] tipos,
        double[] precios,
        boolean[] disponibles,
        int cantidad) {

    boolean hayDisponibles = false;

    System.out.println("\n=== HABITACIONES DISPONIBLES ===");

    for (int i = 0; i < cantidad; i++) {

        if (disponibles[i]) {
            System.out.println("---------------------------");
            System.out.println("Numero: " + numeros[i]);
            System.out.println("Tipo: " + tipos[i]);
            System.out.println("Precio por noche: $" + precios[i]);

            hayDisponibles = true;
        }
    }

    if (!hayDisponibles) {
        System.out.println("No hay habitaciones disponibles.");
    }
}
public static int realizarReserva(
        java.util.Scanner entrada,
        int[] idsClientes,
        int cantidadClientes,
        int[] numerosHabitaciones,
        boolean[] habitacionesDisponibles,
        int cantidadHabitaciones,
        int[] reservasClientes,
        int[] reservasHabitaciones,
        int[] reservasNoches,
        boolean[] reservasActivas,
        int cantidadReservas) {

    if (cantidadReservas >= reservasClientes.length) {
        System.out.println("No se pueden registrar mas reservas.");
        return cantidadReservas;
    }

    if (cantidadClientes == 0 || cantidadHabitaciones == 0) {
        System.out.println("Debe registrar clientes y habitaciones primero.");
        return cantidadReservas;
    }

    System.out.print("Ingrese el ID del cliente: ");

    if (!entrada.hasNextInt()) {
        System.out.println("Error: ingrese un ID numerico.");
        entrada.nextLine();
        return cantidadReservas;
    }

    int idCliente = entrada.nextInt();
    boolean clienteExiste = false;

    for (int i = 0; i < cantidadClientes; i++) {
        if (idsClientes[i] == idCliente) {
            clienteExiste = true;
            break;
        }
    }

    if (!clienteExiste) {
        System.out.println("El cliente no existe.");
        return cantidadReservas;
    }

    System.out.print("Ingrese el numero de habitacion: ");

    if (!entrada.hasNextInt()) {
        System.out.println("Error: ingrese un numero valido.");
        entrada.nextLine();
        return cantidadReservas;
    }

    int numeroHabitacion = entrada.nextInt();
    int posicionHabitacion = -1;

    for (int i = 0; i < cantidadHabitaciones; i++) {
        if (numerosHabitaciones[i] == numeroHabitacion) {
            posicionHabitacion = i;
            break;
        }
    }

    if (posicionHabitacion == -1) {
        System.out.println("La habitacion no existe.");
        return cantidadReservas;
    }

    if (!habitacionesDisponibles[posicionHabitacion]) {
        System.out.println("La habitacion ya esta reservada.");
        return cantidadReservas;
    }

    System.out.print("Ingrese la cantidad de noches: ");

    if (!entrada.hasNextInt()) {
        System.out.println("Error: ingrese un numero de noches valido.");
        entrada.nextLine();
        return cantidadReservas;
    }

    int noches = entrada.nextInt();

    if (noches <= 0) {
        System.out.println("La cantidad de noches debe ser mayor que cero.");
        return cantidadReservas;
    }

    reservasClientes[cantidadReservas] = idCliente;
    reservasHabitaciones[cantidadReservas] = numeroHabitacion;
    reservasNoches[cantidadReservas] = noches;
    reservasActivas[cantidadReservas] = true;

    habitacionesDisponibles[posicionHabitacion] = false;

    cantidadReservas++;

    System.out.println("Reserva realizada correctamente.");
    System.out.println("Numero de reserva: " + cantidadReservas);

    return cantidadReservas;
}
public static void cancelarReserva(
        java.util.Scanner entrada,
        int[] reservasHabitaciones,
        boolean[] reservasActivas,
        int cantidadReservas,
        int[] numerosHabitaciones,
        boolean[] habitacionesDisponibles,
        int cantidadHabitaciones) {

    if (cantidadReservas == 0) {
        System.out.println("No hay reservas registradas.");
        return;
    }

    System.out.print("Ingrese el numero de reserva que desea cancelar: ");

    if (!entrada.hasNextInt()) {
        System.out.println("Error: ingrese un numero valido.");
        entrada.nextLine();
        return;
    }

    int numeroReserva = entrada.nextInt();

    if (numeroReserva < 1 || numeroReserva > cantidadReservas) {
        System.out.println("La reserva no existe.");
        return;
    }

    int posicionReserva = numeroReserva - 1;

    if (!reservasActivas[posicionReserva]) {
        System.out.println("Esta reserva ya fue cancelada.");
        return;
    }

    reservasActivas[posicionReserva] = false;

    int numeroHabitacion = reservasHabitaciones[posicionReserva];

    for (int i = 0; i < cantidadHabitaciones; i++) {
        if (numerosHabitaciones[i] == numeroHabitacion) {
            habitacionesDisponibles[i] = true;
            break;
        }
    }

    System.out.println("Reserva cancelada correctamente.");
    System.out.println("La habitacion vuelve a estar disponible.");
}
public static void consultarReservas(
        int[] reservasClientes,
        int[] reservasHabitaciones,
        int[] reservasNoches,
        boolean[] reservasActivas,
        int cantidadReservas) {

    System.out.println("\n=== CONSULTAR RESERVAS ===");

    if (cantidadReservas == 0) {
        System.out.println("No hay reservas registradas.");
        return;
    }

    for (int i = 0; i < cantidadReservas; i++) {

        System.out.println("---------------------------");
        System.out.println("Numero de reserva: " + (i + 1));
        System.out.println("ID del cliente: " + reservasClientes[i]);
        System.out.println("Numero de habitacion: " + reservasHabitaciones[i]);
        System.out.println("Cantidad de noches: " + reservasNoches[i]);

        if (reservasActivas[i]) {
            System.out.println("Estado: Activa");
        } else {
            System.out.println("Estado: Cancelada");
        }
    }
}
public static void calcularCostoReserva(
        java.util.Scanner entrada,
        int[] reservasHabitaciones,
        int[] reservasNoches,
        boolean[] reservasActivas,
        int cantidadReservas,
        int[] numerosHabitaciones,
        double[] preciosHabitaciones,
        int cantidadHabitaciones) {

    if (cantidadReservas == 0) {
        System.out.println("No hay reservas registradas.");
        return;
    }

    System.out.print("Ingrese el numero de reserva: ");

    if (!entrada.hasNextInt()) {
        System.out.println("Error: ingrese un numero valido.");
        entrada.nextLine();
        return;
    }

    int numeroReserva = entrada.nextInt();

    if (numeroReserva < 1 || numeroReserva > cantidadReservas) {
        System.out.println("La reserva no existe.");
        return;
    }

    int posicionReserva = numeroReserva - 1;

    if (!reservasActivas[posicionReserva]) {
        System.out.println("La reserva esta cancelada.");
        return;
    }

    int numeroHabitacion = reservasHabitaciones[posicionReserva];

    for (int i = 0; i < cantidadHabitaciones; i++) {

        if (numerosHabitaciones[i] == numeroHabitacion) {

            double precio = preciosHabitaciones[i];
            int noches = reservasNoches[posicionReserva];
            double total = precio * noches;

            System.out.println("\n=== COSTO DE LA RESERVA ===");
            System.out.println("Numero de reserva: " + numeroReserva);
            System.out.println("Precio por noche: $" + precio);
            System.out.println("Cantidad de noches: " + noches);
            System.out.println("Total a pagar: $" + total);

            return;
        }
    }

    System.out.println("No se encontro la habitacion de esta reserva.");
}
}