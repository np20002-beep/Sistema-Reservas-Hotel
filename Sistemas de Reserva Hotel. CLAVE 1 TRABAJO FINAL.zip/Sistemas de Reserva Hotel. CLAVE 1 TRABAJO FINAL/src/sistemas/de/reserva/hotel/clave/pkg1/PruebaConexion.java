
package sistemas.de.reserva.hotel.clave.pkg1;

import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class PruebaConexion {

    public static void main(String[] args) {

        try {
            MongoDatabase base = ConexionMongoDB.conectar();

            base.runCommand(new Document("ping", 1));

            System.out.println(
                "Conexion exitosa con MongoDB");

            System.out.println(
                "Base de datos: " + base.getName());

        } catch (Exception e) {

            System.out.println(
                "Error de conexion: " + e.getMessage());

        } finally {
            ConexionMongoDB.cerrar();
        }
    }
}
