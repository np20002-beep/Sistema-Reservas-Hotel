/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Pavilion X360
 */
package sistemas.de.reserva.hotel.clave.pkg1;

public class Reserva {

    private int id;
    private Huesped huesped;
    private Habitacion habitacion;
    private int dias;
    private String estado;
    private double precioPorNoche;

    public Reserva(int id, Huesped huesped, Habitacion habitacion, int dias) {
    this.id = id;
    this.huesped = huesped;
    this.habitacion = habitacion;
    this.dias = dias;
    this.estado = "Activa";
    this.precioPorNoche = habitacion.getPrecio();
}

    public int getId() {
        return id;
    }

    public Huesped getHuesped() {
        return huesped;
    }

    public Habitacion getHabitacion() {
        return habitacion;
    }

    public String getEstado() {
        return estado;
    }

    public void cancelarReserva() {
        this.estado = "Cancelada";
        habitacion.setEstado("Disponible");
    }

   public double calcularCosto() {
    return precioPorNoche * dias;
}

    public void mostrarInformacion() {

        System.out.println("------------------------");
        System.out.println("Reserva numero: " + id);
        System.out.println("Huesped: " + huesped.getNombre());
        System.out.println("Habitacion: " + habitacion.getNumero());
        System.out.println("Dias de hospedaje: " + dias);
        System.out.println("Costo total: $" + calcularCosto());
        System.out.println("Estado: " + estado);
    }
}