package sistemas.de.reserva.hotel.clave.pkg1;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.IndexOptions;
import com.mongodb.client.model.Indexes;
import java.security.SecureRandom;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import org.bson.Document;

public class UsuarioDAO {

    private final MongoCollection<Document> coleccion;

    public UsuarioDAO() {
        coleccion = ConexionMongoDB.conectar()
                .getCollection("usuarios");

        coleccion.createIndex(
                Indexes.ascending("usuario"),
                new IndexOptions().unique(true));
    }

    private byte[] generarHash(char[] contrasena, byte[] salt) {
        PBEKeySpec especificacion =
                new PBEKeySpec(contrasena, salt, 120000, 256);

        try {
            SecretKeyFactory fabrica =
                    SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            return fabrica.generateSecret(especificacion).getEncoded();

        } catch (Exception e) {
            throw new IllegalStateException(
                    "Error al proteger la contraseña.", e);

        } finally {
            especificacion.clearPassword();
        }
    }

    public void registrarUsuario(String usuario, char[] contrasena) {

        usuario = usuario.trim();

        if (usuario.isEmpty() || contrasena.length < 8) {
            throw new IllegalArgumentException(
                    "El usuario es obligatorio y la contraseña debe tener al menos 8 caracteres.");
        }

        if (coleccion.find(Filters.eq("usuario", usuario)).first() != null) {
            throw new IllegalArgumentException(
                    "Este nombre de usuario ya existe.");
        }

        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);

        byte[] hash = generarHash(contrasena, salt);

        Document datos = new Document()
                .append("usuario", usuario)
                .append("salt", Base64.getEncoder().encodeToString(salt))
                .append("hash", Base64.getEncoder().encodeToString(hash));

        coleccion.insertOne(datos);
    }

    public boolean validarAcceso(String usuario, char[] contrasena) {

        Document datos = coleccion.find(
                Filters.eq("usuario", usuario.trim())).first();

        if (datos == null) {
            return false;
        }

        byte[] salt = Base64.getDecoder().decode(
                datos.getString("salt"));

        byte[] hashGuardado = Base64.getDecoder().decode(
                datos.getString("hash"));

        byte[] hashIngresado = generarHash(contrasena, salt);

        return MessageDigest.isEqual(hashGuardado, hashIngresado);
    }
}