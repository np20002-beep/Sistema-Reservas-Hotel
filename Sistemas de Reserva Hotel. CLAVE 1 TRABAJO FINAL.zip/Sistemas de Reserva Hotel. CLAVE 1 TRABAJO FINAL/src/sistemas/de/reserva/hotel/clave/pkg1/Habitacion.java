/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Pavilion X360
 */
package sistemas.de.reserva.hotel.clave.pkg1;

public class Habitacion {

    private int numero;
    private String tipo;
    private double precio;
    private String estado;
    private String codigo;
    private int capacidad;

   public Habitacion(int numero, String tipo, double precio) {
    this("HAB-" + numero, numero, tipo, 1, precio);
}

public Habitacion(String codigo, int numero, String tipo,
                  int capacidad, double precio) {

    if (codigo == null || codigo.isBlank()) {
        throw new IllegalArgumentException(
            "El codigo no puede estar vacio");
    }

    if (numero <= 0) {
        throw new IllegalArgumentException(
            "El numero debe ser mayor que cero");
    }

    if (tipo == null || tipo.isBlank()) {
        throw new IllegalArgumentException(
            "El tipo no puede estar vacio");
    }

    if (capacidad <= 0) {
        throw new IllegalArgumentException(
            "La capacidad debe ser mayor que cero");
    }

    if (precio < 0) {
        throw new IllegalArgumentException(
            "El precio no puede ser negativo");
    }

    this.codigo = codigo;
    this.numero = numero;
    this.tipo = tipo;
    this.capacidad = capacidad;
    this.precio = precio;
    this.estado = "Disponible";
}

    public int getNumero() {
        return numero;
    }

    public String getTipo() {
        return tipo;
    }

    public double getPrecio() {
        return precio;
    }

    public String getEstado() {
        return estado;
    }

    public void setPrecio(double precio) {
        if (precio > 0) {
            this.precio = precio;
        }
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public double calcularCosto(int dias) {
        return precio * dias;
    }

    public void mostrarInformacion() {
        System.out.println("------------------------");
        System.out.println("Habitacion: " + numero);
        System.out.println("Tipo: " + tipo);
        System.out.println("Precio por noche: $" + precio);
        System.out.println("Estado: " + estado);
    }
    public String getCodigo() {
    return codigo;
}

public void setCodigo(String codigo) {
    if (codigo == null || codigo.isBlank()) {
        throw new IllegalArgumentException(
            "El codigo no puede estar vacio");
    }
    this.codigo = codigo;
}

public int getCapacidad() {
    return capacidad;
}

public void setCapacidad(int capacidad) {
    if (capacidad <= 0) {
        throw new IllegalArgumentException(
            "La capacidad debe ser mayor que cero");
    }
    this.capacidad = capacidad;
}

}